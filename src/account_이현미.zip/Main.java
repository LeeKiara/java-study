package account;

public class Main {
    public static void main(String[] args) {
        // 100개의 계좌관리 생성
        AccountManagement accountManagement = new AccountManagement(100);
        accountManagement.run();

        // integer 최대갯수
        // Integer.MAX_VALUE
    }
}
